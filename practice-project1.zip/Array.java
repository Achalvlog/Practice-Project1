package FirstDemo;

public class Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int[] integerArray = new int[5];

	        // Initializing the array
	        for (int i = 0; i < integerArray.length; i++) {
	            integerArray[i] = i * 2; // Assigning values (0, 2, 4, 6, 8)
	        }

	        // Displaying the elements of the array
	        System.out.println("Elements of the integer array:");
	        for (int i = 0; i < integerArray.length; i++) {
	            System.out.print(integerArray[i] + " ");
	        }
	        System.out.println(); // Move to the next line

	        // Creating an array of strings
	        String[] stringArray = {"Java", "is", "fun", "with", "arrays"};

	        // Displaying the elements of the string array
	        System.out.println("Elements of the string array:");
	        for (int i = 0; i < stringArray.length; i++) {
	            System.out.print(stringArray[i] + " ");
	        }
	        System.out.println(); // Move to the next line

	        // Verifying array manipulation
	        int sum = 0;
	        for (int value : integerArray) {
	            sum += value; // Calculating the sum of integerArray
	        }

	        // Displaying the sum of elements in the integer array
	        System.out.println("Sum of elements in the integer array: " + sum);
	    }
	

	}


