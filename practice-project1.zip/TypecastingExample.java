package FirstDemo;

public class TypecastingExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int intValue = 10;
        long longValue = intValue; // Implicit casting from int to long
        float floatValue = longValue; // Implicit casting from long to float
        double doubleValue = floatValue; // Implicit casting from float to double

        System.out.println("Implicit Type Casting:");
        System.out.println("int value: " + intValue);
        System.out.println("long value: " + longValue);
        System.out.println("float value: " + floatValue);
        System.out.println("double value: " + doubleValue);

        // Explicit Type Casting (Narrowing)
        double anotherDoubleValue = 1234.56;
        float anotherFloatValue = (float) anotherDoubleValue; // Explicit casting from double to float
        long anotherLongValue = (long) anotherFloatValue; // Explicit casting from float to long
        int anotherIntValue = (int) anotherLongValue; // Explicit casting from long to int

        System.out.println("\nExplicit Type Casting:");
        System.out.println("double value: " + anotherDoubleValue);
        System.out.println("float value: " + anotherFloatValue);
        System.out.println("long value: " + anotherLongValue);
        System.out.println("int value: " + anotherIntValue);

	}

}
