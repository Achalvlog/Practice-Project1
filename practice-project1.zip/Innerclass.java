package FirstDemo;
class Outer {
    private int outerVar;

    // Inner class
    class Inner {
        void display() {
            System.out.println("Inner class method: " + outerVar);
        }
    }

    // Constructor for Outer class
    public Outer(int outerVar) {
        this.outerVar = outerVar;
    }

    // Method in Outer class that uses Inner class
    public void useInner() {
        Inner innerObj = new Inner();
        innerObj.display();
    }
}


public class Innerclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Outer outerObj = new Outer(10);

        // Call the method in the Outer class that uses the Inner class
        outerObj.useInner();

	}

}
