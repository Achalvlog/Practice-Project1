package FirstDemo;
class Defaultclass{
	void defaultmethod() {
		System.out.print("This is default method");
	}
}

public class Accessmodifier {
	 public void publicMethod() {
	        System.out.println("This is a public method.");
	    }
	 private void privateMethod() {
	        System.out.println("This is a private method.");
	    }

	    // Protected method
	    protected void protectedMethod() {
	        System.out.println("This is a protected method.");
	    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Defaultclass ex= new Defaultclass();
		 ex.defaultmethod();
		 Accessmodifier r = new Accessmodifier();
		 r.publicMethod();

		

	}

}
