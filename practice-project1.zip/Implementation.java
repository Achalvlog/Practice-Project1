package FirstDemo;
 class MathOperations {
    public int add(int a, int b) {
        return a + b;
    }
}



public class Implementation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 public void testAdd() {
		        // Arrange
			 MathOperations calculator = new  MathOperations ();

		        // Act
		        int result = calculator.add(2, 3);

		        // Assert
		        assertEquals(5, result);

	}

}
