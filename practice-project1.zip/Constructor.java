package FirstDemo;

class Constructor {
	  String make;
	    String model;
	    int year;

	    // Default constructor
	    public Constructor() {
	        // Default values
	        make = "Unknown";
	        model = "Unknown";
	        year = 0;
	    }

	    // Parameterized constructor
	    public Constructor(String make, String model, int year) {
	        // Set values based on parameters
	        this.make = make;
	        this.model = model;
	        this.year = year;
	    }

	    // Method to display car information
	    public void displayInfo() {
	        System.out.println("Make: " + make);
	        System.out.println("Model: " + model);
	        System.out.println("Year: " + year);
	    }


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Constructor defaultCar = new Constructor(); // Default constructor
		Constructor paramCar = new Constructor("Toyota", "Camry", 2022); // Parameterized constructor

        // Displaying information
        System.out.println("Default Car:");
        defaultCar.displayInfo();

        System.out.println("\nParameterized Car:");
        paramCar.displayInfo();

	}

}
