package FirstDemo;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;

public class Regularexpression {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);

        // Define a regular expression pattern
        String regexPattern = "[a-zA-Z]+";

        // Compile the pattern into a regex object
        Pattern pattern = Pattern.compile(regexPattern);

        // Get user input
        System.out.println("Enter a string to verify:");
        String input = scanner.nextLine();

        // Create a matcher object
        Matcher matcher = pattern.matcher(input);

        // Check if the input matches the pattern
        if (matcher.matches()) {
            System.out.println("Input is valid and matches the pattern.");
        } else {
            System.out.println("Input is invalid and does not match the pattern.");
        }

        scanner.close();
		

	}

}
