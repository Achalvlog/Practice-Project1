package FirstDemo;
import java.util.ArrayList;
import java.util.List;

class Collection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		testListImplementation();
        System.out.println("All tests passed!");
    }

    private static void testListImplementation() {
        // Replace ArrayList with the specific List implementation you want to test
        List<String> myList = new ArrayList<>();

        // Test adding elements
        myList.add("Element 1");
        myList.add("Element 2");

        // Test size
        assert myList.size() == 2 : "Size should be 2";

        // Test getting elements
        assert myList.get(0).equals("Element 1") : "Element at index 0 should be 'Element 1'";
        assert myList.get(1).equals("Element 2") : "Element at index 1 should be 'Element 2'";

        // Test removing elements
        myList.remove("Element 1");
        assert myList.size() == 1 : "Size should be 1 after removal";

        // Test clearing the list
        myList.clear();
        assert myList.size() == 0 : "Size should be 0 after clearing";
        assert myList.isEmpty() : "List should be empty after clearing";

	}

}
