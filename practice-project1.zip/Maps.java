package FirstDemo;
import java.util.*;

public class Maps {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Map<String, Integer> map = new HashMap<>();

	        // Add elements to the map
	        map.put("One", 1);
	        map.put("Two", 2);
	        map.put("Three", 3);

	        // Display the initial map
	        System.out.println("Initial Map: " + map);

	        // Verify if a key exists
	        String keyToCheck = "Two";
	        if (map.containsKey(keyToCheck)) {
	            System.out.println(keyToCheck + " exists in the map with value: " + map.get(keyToCheck));
	        } else {
	            System.out.println(keyToCheck + " does not exist in the map.");
	        }

	        // Remove an element from the map
	        String keyToRemove = "Two";
	        if (map.containsKey(keyToRemove)) {
	            map.remove(keyToRemove);
	            System.out.println(keyToRemove + " removed. Updated Map: " + map);
	        } else {
	            System.out.println(keyToRemove + " does not exist in the map.");
	        }

	        // Iterate through the map
	        System.out.println("Iterating through the map:");
	        for (Map.Entry<String, Integer> entry : map.entrySet()) {
	            System.out.println(entry.getKey() + ": " + entry.getValue());
	        }

	        // Clear the map
	        map.clear();
	        System.out.println("Map cleared. Is the map empty? " + map.isEmpty());

	}

}
